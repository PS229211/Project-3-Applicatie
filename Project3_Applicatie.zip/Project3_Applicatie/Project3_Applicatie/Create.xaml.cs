﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for Create.xaml
    /// </summary>
    public partial class Create : Window
    {
        public Create()
        {
            InitializeComponent();
        }

        private void CreatePartij_Click(object sender, RoutedEventArgs e)
        {
            PartijenDB partijenDB = new PartijenDB();
            if (partijenDB.InsertPartij(tbPartijNaam.Text, tbAdres.Text, tbPostcode.Text, tbGemeente.Text, tbEmailadres.Text, tbTelefoonnummer.Text))
            {
                MessageBox.Show($"partij aangemaakt");
            }
            else
            {
                MessageBox.Show($"Aanmaken mislukt");
            }
            this.Close();
        }
    }
}

