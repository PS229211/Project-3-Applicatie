﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for EditPartij.xaml
    /// </summary>
    public partial class EditPartij : Window
    {
        public EditPartij(DataRowView partij)
        {
            InitializeComponent();
            FillScreen(partij);
        }

        private void FillScreen(DataRowView partij)
        {
            tbEditPartijId.Text = partij["partij_id"].ToString();
            tbEditPartijNaam.Text = partij["naam"].ToString();
            tbEditPartijAdres.Text = partij["adres"].ToString();
            tbEditPartijPostcode.Text = partij["postcode"].ToString();
            tbEditPartijGemeente.Text = partij["gemeente"].ToString();
            tbEditPartijEmailadres.Text = partij["emailadres"].ToString();
            tbEditPartijTelefoonnummer.Text = partij["telefoonnummer"].ToString();
        }

        private void UpdatePartij_Click(object sender, RoutedEventArgs e)
        {
            PartijenDB partijenDB = new PartijenDB();
            if (partijenDB.UpdatePartij(tbEditPartijId.Text, tbEditPartijNaam.Text, tbEditPartijAdres.Text, tbEditPartijPostcode.Text, tbEditPartijGemeente.Text, tbEditPartijEmailadres.Text, tbEditPartijTelefoonnummer.Text))
            {
                MessageBox.Show($"Partij {tbEditPartijId.Text} aangepast");
            }
            else
            {
                MessageBox.Show($"Aanpassen van {tbEditPartijId.Text} mislukt");
            }
            this.Close();
        }
    }
}
