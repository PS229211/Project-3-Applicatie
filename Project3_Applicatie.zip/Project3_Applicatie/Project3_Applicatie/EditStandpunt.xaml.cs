﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for EditStandpunt.xaml
    /// </summary>
    public partial class EditStandpunt : Window
    {
        public EditStandpunt(DataRowView standpunt)
        {
            InitializeComponent();
            FillScreen(standpunt);
        }

        private void FillScreen(DataRowView standpunt)
        {
            tbEditStandpuntid.Text = standpunt["standpunt_id"].ToString();
            tbEditStandpunt.Text = standpunt["standpunt"].ToString();
            tbEditStandpuntThema.Text = standpunt["thema_id"].ToString();
        }

        private void EditStandpunt_Click(object sender, RoutedEventArgs e)
        {
            StandpuntDB standpuntDB = new StandpuntDB();
            if (standpuntDB.UpdateStandpunt(tbEditStandpuntid.Text, tbEditStandpunt.Text, tbEditStandpuntThema.Text))
            {
                MessageBox.Show($"Standpunt {tbEditStandpuntid.Text} aangepast");
            }
            else
            {
                MessageBox.Show($"Aanpassen van {tbEditStandpuntid.Text} mislukt");
            }
            this.Close();
        }
    }
}

