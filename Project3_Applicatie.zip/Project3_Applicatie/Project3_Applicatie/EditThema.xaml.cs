﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for EditThema.xaml
    /// </summary>
    public partial class EditThema : Window
    {
        public EditThema(DataRowView thema)
        {
            InitializeComponent();
            FillScreen(thema);
        }

        private void FillScreen(DataRowView thema)
        {
            tbEditId.Text = thema["thema_id"].ToString();
            tbEditThema.Text = thema["thema"].ToString();
        }

        private void UpdateThema_Click(object sender, RoutedEventArgs e)
        {
            ThemasDB themasDB = new ThemasDB();
            if (themasDB.UpdateThema(tbEditId.Text, tbEditThema.Text))
            {
                MessageBox.Show($"Thema {tbEditId.Text} aangepast");
            }
            else
            {
                MessageBox.Show($"Aanpassen van {tbEditId.Text} mislukt");
            }
            this.Close();
        }
    }
}
