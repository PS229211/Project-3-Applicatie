﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for EditStandpunt.xaml
    /// </summary>
    public partial class EditVerkiezing : Window
    {
        public EditVerkiezing(DataRowView verkiezing)
        {
            InitializeComponent();
            FillScreen(verkiezing);
        }

        private void FillScreen(DataRowView verkiezing)
        {
            tbEditVerkiezingid.Text = verkiezing["verkiezing_id"].ToString();
            tbEditVerkiezingsoort.Text = verkiezing["verkiezingsoortID"].ToString();
            tbEditVerkiezingDatum.Text = verkiezing["Datum"].ToString();
        }

        private void EditVerkiezing_Click(object sender, RoutedEventArgs e)
        {
            VerkiezingDB verkiezingDB = new VerkiezingDB();
            if (verkiezingDB.UpdateVerkiezing(tbEditVerkiezingid.Text, tbEditVerkiezingsoort.Text, tbEditVerkiezingDatum.SelectedDate))
            {
                MessageBox.Show($"Standpunt {tbEditVerkiezingid.Text} aangepast");
            }
            else
            {
                MessageBox.Show($"Aanpassen van {tbEditVerkiezingid.Text} mislukt");
            }
            this.Close();
        }
    }
}
