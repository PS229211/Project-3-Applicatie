﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

        private void PartijenOpenWindow(object sender, RoutedEventArgs e)
        {
            PartijenWindow objPartijenwindow = new PartijenWindow();
            this.Visibility = Visibility.Visible;
            objPartijenwindow.Show();
        }

        private void VerkiezingssoortenOpenWindow(object sender, RoutedEventArgs e)
        {
            VerkiezingssoortenWindow objVerkiezingssoortenWindow = new VerkiezingssoortenWindow();
            this.Visibility = Visibility.Visible;
            objVerkiezingssoortenWindow.Show();
        }

        private void ThemaOpenWindow(object sender, RoutedEventArgs e)
        {
            ThemaWindow objThemaWindow = new ThemaWindow();
            this.Visibility = Visibility.Visible;
            objThemaWindow.Show();
        }

        private void StandpuntOpenWindow(object sender, RoutedEventArgs e)
        {
            StandpuntWindow objStandpuntWindow = new StandpuntWindow();
            this.Visibility = Visibility.Visible;
            objStandpuntWindow.Show();
        }

        private void VerkiezingOpenWindow(object sender, RoutedEventArgs e)
        {
            VerkiezingWindow objVerkiezingWindow = new VerkiezingWindow();
            this.Visibility = Visibility.Visible;
            objVerkiezingWindow.Show();
        }

        /*        private void ThemaOpenWindow(object sender, RoutedEventArgs e)
                {

                }*/
    }
}


