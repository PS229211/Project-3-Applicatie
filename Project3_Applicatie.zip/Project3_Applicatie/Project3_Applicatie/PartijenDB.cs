﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3_Applicatie.Classes
{
    internal class PartijenDB
    {
        #region fields
        MySqlConnection _connection = new MySqlConnection("Server=localhost;Database=verkiezingenprj3;Uid=root;Pwd=;");

        public DataView ItemsSource { get; internal set; }
        #endregion

        #region methods/functions
        public DataTable SelectPartijen()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "SELECT * FROM partij;";
                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception)
            {
                //Problem with the database
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }

/*        internal bool InsertPartij(string text1, string text2, string text3, string text4, string text5, string text6)
        {
            throw new NotImplementedException();
        }*/

        public bool InsertPartij(string partijNaam, string adres, string postcode, string gemeente, string emailadres, string telefoonnummer)
        {
            bool succes = false;
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "INSERT INTO `partij` (`naam`, `adres`, `postcode`, `gemeente`, `emailadres`, `telefoonnummer`) VALUES (@partijNaam, @adres, @postcode, @gemeente, @emailadres, @telefoonnummer) ";
                command.Parameters.AddWithValue("@partijNaam", partijNaam);
                command.Parameters.AddWithValue("@adres", adres);
                command.Parameters.AddWithValue("@postcode", postcode);
                command.Parameters.AddWithValue("@gemeente", gemeente);
                command.Parameters.AddWithValue("@emailadres", emailadres);
                command.Parameters.AddWithValue("@telefoonnummer", telefoonnummer);
/*                command.Parameters.AddWithValue("@partij_id", ID);*/
                int nrOfRowsAffected = command.ExecuteNonQuery();
                succes = (nrOfRowsAffected != 0);
            }
            catch (Exception)
            {
                //Problem with the database
            }
            finally
            {
                _connection.Close();
            }
            return succes;
        }

        public bool UpdatePartij(string id, string partijNaam, string adres, string postcode, string gemeente, string emailadres, string telefoonnummer)
        {
            bool succes = false;
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "UPDATE `partij` SET `naam` = @partijNaam, `adres` = @adres, `postcode` = @postcode, `gemeente` = @gemeente, `emailadres` = @emailadres, `telefoonnummer` = @telefoonnummer WHERE `partij`.`partij_id` = @id; ";
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@partijNaam", partijNaam);
                command.Parameters.AddWithValue("@adres", adres);
                command.Parameters.AddWithValue("@postcode", postcode);
                command.Parameters.AddWithValue("@gemeente", gemeente);
                command.Parameters.AddWithValue("@emailadres", emailadres);
                command.Parameters.AddWithValue("@telefoonnummer", telefoonnummer);
                int nrOfRowsAffected = command.ExecuteNonQuery();
                succes = (nrOfRowsAffected != 0);
            }
            catch (Exception)
            {
                //Problem with the database
            }
            finally
            {
                _connection.Close();
            }
            return succes;
        }

        public bool DeletePartij(string id)
        {
            bool succes = false;
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "DELETE FROM `partij` WHERE `partij`.`partij_id` = @id;";
                command.Parameters.AddWithValue("@id", id);
                int nrOfRowsAffected = command.ExecuteNonQuery();
                succes = (nrOfRowsAffected != 0);
            }
            catch (Exception)
            {
                //Problem with the database
            }
            finally
            {
                _connection.Close();
            }
            return succes;
        }
        #endregion
    }
}
