﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class PartijenWindow : Window
    {
        PartijenDB _partijenDB = new PartijenDB();
        public PartijenWindow()
        {
            InitializeComponent();
            FillDataGrid();
        }

        private void FillDataGrid()
        {
            DataTable partijen = _partijenDB.SelectPartijen();
            if (partijen != null)
            {
                dgPartijen.ItemsSource = partijen.DefaultView;
            }
        }

        private void UpdatePartij_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgPartijen.SelectedItem as DataRowView;

            EditPartij edit = new EditPartij(selectedRow);
            edit.ShowDialog();
            FillDataGrid();
        }

        private void CreatePartij_Click(object sender, RoutedEventArgs e)
        {
            Create create = new Create();
            create.ShowDialog();
            FillDataGrid();
        }

        private void DeletePartij_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgPartijen.SelectedItem as DataRowView;

            if (_partijenDB.DeletePartij(selectedRow["partij_id"].ToString()))
            {
                MessageBox.Show($"Partij {selectedRow["partij_id"]} verwijderd");
            }
            else
            {
                MessageBox.Show($"Verwijderen van {selectedRow["partij_id"]} mislukt");
            }

            FillDataGrid();
        }
    }
}
