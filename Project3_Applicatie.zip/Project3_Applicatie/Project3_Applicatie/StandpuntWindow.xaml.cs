﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class StandpuntWindow : Window
    {
        StandpuntDB _standpuntDB = new StandpuntDB();
        public StandpuntWindow()
        {
            InitializeComponent();
            FillDataGrid();
        }

        private void FillDataGrid()
        {
            DataTable standpunt = _standpuntDB.SelectStandpunt();
            if (standpunt != null)
            {
                dgStandpunt.ItemsSource = standpunt.DefaultView;
            }
        }

        private void UpdateStandpunt_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgStandpunt.SelectedItem as DataRowView;

            EditStandpunt edit = new EditStandpunt(selectedRow);
            edit.ShowDialog();
            FillDataGrid();
        }

        private void CreateStandpunt_Click(object sender, RoutedEventArgs e)
        {
            CreateStandpunt create = new CreateStandpunt();
            create.ShowDialog();
            FillDataGrid();
        }

        private void DeleteStandpunt_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgStandpunt.SelectedItem as DataRowView;

            if (_standpuntDB.DeleteStandpunt(selectedRow["standpunt_id"].ToString()))
            {
                MessageBox.Show($"Standpunt {selectedRow["standpunt_id"]} verwijderd");
            }
            else
            {
                MessageBox.Show($"Verwijderen van {selectedRow["standpunt_id"]} mislukt");
            }

            FillDataGrid();
        }
    }
}
