﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class ThemaWindow : Window
    {
        ThemasDB _themasDB = new ThemasDB();

        public ThemaWindow()
        {
            InitializeComponent();
            FillDataGrid();
        }

        private void FillDataGrid()
        {
            DataTable themas = _themasDB.SelectThemas();
            if (themas != null)
            {

                dgThemas.ItemsSource = themas.DefaultView;
            }
        }

        private void CreateThema_Click(object sender, RoutedEventArgs e)
        {
            CreateThema create = new CreateThema();
            create.ShowDialog();
            FillDataGrid();
        }

        private void UpdateThema_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgThemas.SelectedItem as DataRowView;

            EditThema edit = new EditThema(selectedRow);
            edit.ShowDialog();
            FillDataGrid();
        }

        private void DeleteThema_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgThemas.SelectedItem as DataRowView;

            if (_themasDB.DeleteThema(selectedRow["thema_id"].ToString()))
            {
                MessageBox.Show($"Thema {selectedRow["thema_id"]} verwijderd");
            }
            else
            {
                MessageBox.Show($"Verwijderen van {selectedRow["thema_id"]} mislukt");
            }

            FillDataGrid();
        }

        /*        private void Update_Click(object sender, RoutedEventArgs e)
                {
                    DataRowView selectedRow = dgThemas.SelectedItem as DataRowView;

                    Edit edit = new Edit(selectedRow);
                    edit.ShowDialog();
                }*/
    }
}
