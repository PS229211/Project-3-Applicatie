﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class VerkiezingWindow : Window
    {
        VerkiezingDB _verkiezingDB = new VerkiezingDB();
        public VerkiezingWindow()
        {
            InitializeComponent();
            FillDataGrid();
        }

        private void FillDataGrid()
        {
            DataTable verkiezing = _verkiezingDB.SelectVerkiezing();
            if (verkiezing != null)
            {
                dgVerkiezing.ItemsSource = verkiezing.DefaultView;
            }
        }

        private void UpdateVerkiezing_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgVerkiezing.SelectedItem as DataRowView;

            EditVerkiezing edit = new EditVerkiezing(selectedRow);
            edit.ShowDialog();
            FillDataGrid();
        }

        private void CreateVerkiezing_Click(object sender, RoutedEventArgs e)
        {
            CreateVerkiezing create = new CreateVerkiezing();
            create.ShowDialog();
            FillDataGrid();
        }

        private void DeleteVerkiezing_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgVerkiezing.SelectedItem as DataRowView;

            if (_verkiezingDB.DeleteVerkiezing(selectedRow["verkiezing_id"].ToString()))
            {
                MessageBox.Show($"Verkiezing {selectedRow["verkiezing_id"]} verwijderd");
            }
            else
            {
                MessageBox.Show($"Verwijderen van {selectedRow["verkiezing_id"]} mislukt");
            }

            FillDataGrid();
        }
    }
}
