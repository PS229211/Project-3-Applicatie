﻿using Project3_Applicatie.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project3_Applicatie
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class VerkiezingssoortenWindow : Window
    {
        VerkiezingssoortenDB _verkiezingssoortenDB = new VerkiezingssoortenDB();

        public VerkiezingssoortenWindow()
        {
            InitializeComponent();
            FillDataGrid();
        }

        private void FillDataGrid()
        {
            DataTable verkiezingssoorten = _verkiezingssoortenDB.SelectVerkiezingssoorten();
            if (verkiezingssoorten != null)
            {

                dgVerkiezingssoorten.ItemsSource = verkiezingssoorten.DefaultView;
            }
        }

        private void CreateVerkiezingsoort_Click(object sender, RoutedEventArgs e)
        {
            CreateVerkiezingsoort create = new CreateVerkiezingsoort();
            create.ShowDialog();
            FillDataGrid();
        }

        private void UpdateVerkiezingsoort_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgVerkiezingssoorten.SelectedItem as DataRowView;

            EditVerkiezingsoort edit = new EditVerkiezingsoort(selectedRow);
            edit.ShowDialog();
            FillDataGrid();
        }

        private void DeleteVerkiezingsoort_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = dgVerkiezingssoorten.SelectedItem as DataRowView;

            if (_verkiezingssoortenDB.DeleteVerkiezingsoort(selectedRow["verkiezingsoort_id"].ToString()))
            {
                MessageBox.Show($"Verkiezingsoort {selectedRow["verkiezingsoort_id"]} verwijderd");
            }
            else
            {
                MessageBox.Show($"Verwijderen van {selectedRow["verkiezingsoort_id"]} mislukt");
            }

            FillDataGrid();
        }
    }
}
